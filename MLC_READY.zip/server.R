server <- function(input, output, session) {
  
  mlc_f <- reactive({
    req(input$rango_fecha)
    MLC %>% filter(fecha >= input$rango_fecha[1], fecha <= input$rango_fecha[2])
  })
  
  output$alerta_desempleo <- renderUI({
    df    <- mlc_f()
    ult   <- tail(df$tasa_desempleo_nacional, 1)
    fecha <- format(tail(df$fecha, 1), "%b %Y")
    if (ult > UMBRAL_ALERTA + 3) {
      clase  <- "danger"; icono <- icon("triangle-exclamation")
      titulo <- paste0("ALERTA CRITICA - Desempleo en ", round(ult,1), "%")
      texto  <- paste0("El ultimo dato disponible (", fecha, ") supera en mas de 3 puntos el umbral de alerta (",
                       UMBRAL_ALERTA, "%). Se recomienda revision de politica laboral urgente.")
    } else if (ult > UMBRAL_ALERTA) {
      clase  <- "warning"; icono <- icon("circle-exclamation")
      titulo <- paste0("ATENCION - Desempleo en ", round(ult,1), "%")
      texto  <- paste0("El ultimo dato (", fecha, ") supera el umbral de alerta del ", UMBRAL_ALERTA,
                       "%. El mercado laboral muestra senales de tension.")
    } else {
      clase  <- "ok"; icono <- icon("circle-check")
      titulo <- paste0("BAJO CONTROL - Desempleo en ", round(ult,1), "%")
      texto  <- paste0("El ultimo dato disponible (", fecha, ") se encuentra por debajo del umbral de alerta (",
                       UMBRAL_ALERTA, "%). El mercado laboral opera en zona de estabilidad.")
    }
    tags$div(class = paste("alerta-box", clase),
             tags$span(icono, class = "alerta-icon"),
             tags$div(
               tags$div(titulo, class = "alerta-titulo"),
               tags$p(texto,   class = "alerta-texto")))
  })
  
  output$kpi_media <- renderUI({
    val <- round(mean(mlc_f()$tasa_desempleo_nacional), 2)
    tags$div(class = "kpi-card",
             tags$span("Desempleo promedio", class = "kpi-label"),
             tags$span(class = "kpi-valor blue ndq-counter",
                       `data-target` = val, `data-sufijo` = "%", `data-dec` = "2", val),
             tags$span("Media del periodo seleccionado", class = "kpi-sub"))
  })
  
  output$kpi_min <- renderUI({
    df    <- mlc_f()
    val   <- round(min(df$tasa_desempleo_nacional), 2)
    fecha <- format(df$fecha[which.min(df$tasa_desempleo_nacional)], "%b %Y")
    tags$div(class = "kpi-card green",
             tags$span("Minimo historico", class = "kpi-label"),
             tags$span(class = "kpi-valor green ndq-counter",
                       `data-target` = val, `data-sufijo` = "%", `data-dec` = "2", val),
             tags$span(fecha, class = "kpi-sub"))
  })
  
  output$kpi_max <- renderUI({
    df    <- mlc_f()
    val   <- round(max(df$tasa_desempleo_nacional), 2)
    fecha <- format(df$fecha[which.max(df$tasa_desempleo_nacional)], "%b %Y")
    tags$div(class = "kpi-card red",
             tags$span("Maximo historico", class = "kpi-label"),
             tags$span(class = "kpi-valor red ndq-counter",
                       `data-target` = val, `data-sufijo` = "%", `data-dec` = "2", val),
             tags$span(fecha, class = "kpi-sub"))
  })
  
  output$kpi_obs <- renderUI({
    n <- nrow(mlc_f())
    tags$div(class = "kpi-card orange",
             tags$span("Observaciones", class = "kpi-label"),
             tags$span(class = "kpi-valor orange ndq-counter",
                       `data-target` = n, `data-sufijo` = "", `data-dec` = "0", n),
             tags$span("Meses en el periodo", class = "kpi-sub"))
  })
  
  output$hallazgos_ui <- renderUI({
    df     <- mlc_f()
    media  <- round(mean(df$tasa_desempleo_nacional), 1)
    maximo <- round(max(df$tasa_desempleo_nacional), 1)
    minimo <- round(min(df$tasa_desempleo_nacional), 1)
    corr   <- round(cor(df$tasa_desempleo_nacional, df$tasa_ocupacion_nacional), 3)
    covid  <- df %>% filter(year(fecha) == 2020) %>% pull(tasa_desempleo_nacional) %>% max() %>% round(1)
    rango  <- round(maximo - minimo, 1)
    
    hallazgo <- function(fa_icon, bg, titulo, texto) {
      tags$div(class = "hallazgo-card",
               tags$div(class = "hallazgo-icon", style = paste0("background:", bg, ";"),
                        icon(fa_icon)),
               tags$div(
                 tags$div(titulo, class = "hallazgo-titulo"),
                 tags$p(texto,   class = "hallazgo-texto")))
    }
    
    tags$div(
      hallazgo("chart-line","#dbeafe","Desempleo promedio del periodo",
               paste0("La tasa media de desempleo nacional en el periodo seleccionado fue del ", media,
                      "%, con un rango de variacion de ", rango, " puntos porcentuales entre el minimo (",
                      minimo, "%) y el maximo (", maximo, "%).")),
      hallazgo("virus","#fee2e2","Impacto COVID-19 (2020)",
               paste0("El pico maximo de desempleo durante 2020 alcanzo el ", covid,
                      "%, representando la mayor ruptura estructural del periodo analizado. ",
                      "Este choque externo supero cualquier crisis previa registrada en la serie.")),
      hallazgo("link","#d1fae5","Correlacion desempleo-ocupacion",
               paste0("La correlacion de Pearson entre la tasa de desempleo y la tasa de ocupacion nacional es de ", corr,
                      ", confirmando la relacion inversa fuerte y estadisticamente significativa planteada en la hipotesis principal del estudio.")),
      hallazgo("rotate","#f0f4ff","Estacionalidad anual comprobada",
               "La descomposicion multiplicativa revela un patron estacional anual consistente: el desempleo tiende a ser mayor en los primeros meses del ano (enero-marzo) y a moderarse en el segundo semestre, reflejando ciclos de contratacion del mercado laboral colombiano."),
      hallazgo("building","#fefce8","Brecha area vs nacional",
               "La tasa de desempleo en las 13 areas metropolitanas es sistematicamente superior a la nacional, con una correlacion > 0.94 entre ambas series. Esto sugiere que las zonas urbanas concentran la presion del desempleo estructural del pais."),
      hallazgo("arrow-trend-down","#f0fdf4","Tendencia de largo plazo",
               paste0("A pesar de la volatilidad coyuntural, la tendencia de largo plazo del desempleo muestra una senda descendente desde los niveles del 2001-2003 (~18%) hasta el periodo pre-pandemia (~10%), ",
                      "indicando mejoras estructurales en la capacidad de generacion de empleo de la economia colombiana."))
    )
  })
  
  # -----------------------------------------------------------------------
  # RESUMEN ESTADISTICO - celdas interactivas con definicion al hacer clic
  # -----------------------------------------------------------------------
  output$resumen_desempleo <- renderUI({
    df <- mlc_f()
    s  <- df %>%
      summarise(
        n       = n(),
        media   = round(mean(tasa_desempleo_nacional),   4),
        ds      = round(sd(tasa_desempleo_nacional),     4),
        mediana = round(median(tasa_desempleo_nacional), 4),
        minimo  = round(min(tasa_desempleo_nacional),    4),
        maximo  = round(max(tasa_desempleo_nacional),    4),
        Q1      = round(quantile(tasa_desempleo_nacional, .25), 4),
        Q3      = round(quantile(tasa_desempleo_nacional, .75), 4),
        IQR     = round(IQR(tasa_desempleo_nacional),   4)
      )
    
    kpi_cell <- function(label, value, color, def_key) {
      tags$div(
        class   = "resumen-kpi-cell",
        onclick = paste0("mostrarDefResumen('", def_key, "', this)"),
        title   = paste0("Clic para ver la definicion de ", label),
        tags$span(label, class = "resumen-kpi-label"),
        tags$div(as.character(value),
                 class = "resumen-kpi-value",
                 style = paste0("color:", color, ";"))
      )
    }
    
    tags$div(
      tags$div(class = "resumen-kpi-grid",
               kpi_cell("N",       s$n,       "#374151", "N"),
               kpi_cell("Media",   s$media,   "#185FA5", "Media"),
               kpi_cell("DS",      s$ds,      "#185FA5", "DS"),
               kpi_cell("Mediana", s$mediana, "#185FA5", "Mediana"),
               kpi_cell("Minimo",  s$minimo,  "#0F6E56", "Minimo"),
               kpi_cell("Maximo",  s$maximo,  "#A32D2D", "Maximo"),
               kpi_cell("Q1",      s$Q1,      "#374151", "Q1"),
               kpi_cell("Q3",      s$Q3,      "#374151", "Q3"),
               kpi_cell("IQR",     s$IQR,     "#374151", "IQR")
      ),
      tags$div(
        id    = "resumen-def-panel",
        class = "resumen-def-panel",
        style = "display:none;",
        tags$div(id = "resumen-def-nombre", class = "resumen-def-nombre"),
        tags$p(id  = "resumen-def-texto",   class = "resumen-def-texto"),
        tags$p(id  = "resumen-def-formula", class = "resumen-def-formula")
      )
    )
  })
  
  output$histograma <- renderPlotly({
    df    <- mlc_f()
    media <- mean(df$tasa_desempleo_nacional)
    med   <- median(df$tasa_desempleo_nacional)
    p <- plot_ly(df, x=~tasa_desempleo_nacional, type="histogram", nbinsx=30,
                 marker=list(color=ndq_p_azul, line=list(color="white",width=.8)),
                 name="Frecuencia") %>%
      add_lines(x=c(media,media), y=c(0,55), line=list(color=ndq_p_rojo,  dash="dash",width=2), name="Media") %>%
      add_lines(x=c(med,med),     y=c(0,55), line=list(color=ndq_p_verde, dash="dash",width=2), name="Mediana")
    plotly_layout(p, "Distribucion - Tasa de Desempleo Nacional")
  })
  
  output$boxplot <- renderPlotly({
    p <- plot_ly(mlc_f(), y=~tasa_desempleo_nacional, type="box",
                 marker=list(color=ndq_p_rojo,size=4),
                 line=list(color=ndq_p_azul,width=2),
                 fillcolor=paste0(ndq_p_azul,"55"),
                 name="Desempleo Nacional")
    plotly_layout(p, "Boxplot - Tasa de Desempleo Nacional")
  })
  
  output$dispersion <- renderPlotly({
    df      <- mlc_f()
    Q1      <- quantile(df$tasa_desempleo_nacional,.25)
    Q3      <- quantile(df$tasa_desempleo_nacional,.75)
    IQR_val <- IQR(df$tasa_desempleo_nacional)
    df <- df %>%
      mutate(etiqueta=ifelse(tasa_desempleo_nacional<(Q1-1.5*IQR_val)|
                               tasa_desempleo_nacional>(Q3+1.5*IQR_val),"Outlier","Normal"),
             tooltip=paste0("Fecha: ",format(fecha,"%b %Y"),"<br>Tasa: ",round(tasa_desempleo_nacional,2),"%"))
    p <- plot_ly(df, x=~fecha, y=~tasa_desempleo_nacional, type="scatter", mode="markers",
                 color=~etiqueta, colors=c("Normal"=ndq_p_azul,"Outlier"=ndq_p_rojo),
                 marker=list(size=6,opacity=.85), text=~tooltip, hoverinfo="text")
    plotly_layout(p, "Dispersion temporal - Outliers resaltados")
  })
  
  output$tabla_desc <- renderDT({
    mlc_f() %>% select(-fecha) %>%
      pivot_longer(everything(), names_to="Variable", values_to="valor") %>%
      group_by(Variable) %>%
      summarise(n=n(), Media=round(mean(valor),3), Mediana=round(median(valor),3),
                DS=round(sd(valor),3), Min=round(min(valor),3), Max=round(max(valor),3),
                Q1=round(quantile(valor,.25),3), Q3=round(quantile(valor,.75),3),
                IQR=round(IQR(valor),3), .groups="drop") %>%
      datatable(options=list(pageLength=10,scrollX=TRUE), class="display compact stripe")
  })
  
  output$missmap <- renderPlot({
    par(bg="white")
    missmap(mlc_f(), main="Mapa de datos faltantes", col=c("#f4a3a3","#e8ecf0"), legend=TRUE)
  })
  
  output$tabla_caracteristicas <- renderDT({
    mlc_f() %>%
      select(-fecha, -tasa_desempleo_nacional) %>%
      pivot_longer(everything(), names_to="Variable", values_to="valor") %>%
      group_by(Variable) %>%
      summarise(N=n(), Media=round(mean(valor),3), Mediana=round(median(valor),3),
                DS=round(sd(valor),3), Min=round(min(valor),3), Max=round(max(valor),3),
                Q1=round(quantile(valor,.25),3), Q3=round(quantile(valor,.75),3),
                IQR=round(IQR(valor),3), .groups="drop") %>%
      datatable(rownames=FALSE,
                options=list(pageLength=10, scrollX=TRUE, dom="ft"),
                class="display compact stripe") %>%
      formatStyle("N",   color="#185FA5", fontWeight="500") %>%
      formatStyle("Min", color="#0F6E56", fontWeight="500") %>%
      formatStyle("Max", color="#A32D2D", fontWeight="500")
  })
  
  output$boxplots_caracteristicas <- renderPlotly({
    df_long <- mlc_f() %>% select(-fecha,-tasa_desempleo_nacional) %>%
      pivot_longer(everything(), names_to="variable", values_to="valor")
    p <- plot_ly(df_long, x=~variable, y=~valor, type="box",
                 marker=list(color=ndq_p_azul,size=3),
                 line=list(color=ndq_p_cielo,width=1.5),
                 fillcolor=paste0(ndq_p_azul,"44"))
    plotly_layout(p, "Distribucion por indicador")
  })
  
  output$correlacion <- renderPlotly({
    mat <- mlc_f() %>% select(-fecha) %>%
      cor(use="complete.obs", method="pearson")
    
    labs <- c(
      tasa_global_participacion_area     = "TGP Area",
      tasa_global_participacion_nacional = "TGP Nal.",
      tasa_desempleo_area                = "TD Area",
      tasa_desempleo_nacional            = "TD Nal.",
      tasa_ocupacion_area                = "TO Area",
      tasa_ocupacion_nacional            = "TO Nal."
    )
    colnames(mat) <- labs[colnames(mat)]
    rownames(mat) <- labs[rownames(mat)]
    
    texto <- matrix(
      paste0("<b>", rep(rownames(mat), each=ncol(mat)), "</b> x ",
             "<b>", rep(colnames(mat), nrow(mat)), "</b><br>",
             "r = ", round(as.vector(mat), 3)),
      nrow=nrow(mat)
    )
    
    plot_ly(z=mat, x=colnames(mat), y=rownames(mat), type="heatmap",
            colorscale=list(c(0,ndq_p_rojo), c(0.5,"#f5f5f0"), c(1,ndq_p_azul)),
            zmin=-1, zmax=1, text=texto, hoverinfo="text", showscale=TRUE) %>%
      add_annotations(x=rep(colnames(mat), nrow(mat)),
                      y=rep(rownames(mat), each=ncol(mat)),
                      text=round(as.vector(t(mat)), 2),
                      showarrow=FALSE,
                      font=list(color="#1a1a2e", size=12, family="Inter")) %>%
      layout(title=list(text="Matriz de correlaciones (Pearson)",
                        font=list(color=ndq_text, size=14, family="Inter")),
             paper_bgcolor=ndq_bg, plot_bgcolor=ndq_bg,
             font=list(color=ndq_text, family="Inter"),
             xaxis=list(tickfont=list(size=11, color=ndq_sub), side="bottom"),
             yaxis=list(tickfont=list(size=11, color=ndq_sub), autorange="reversed"),
             margin=list(t=60, r=40, b=60, l=90))
  })
  
  output$pares <- renderPlotly({
    df <- mlc_f()
    g1 <- plot_ly(df, x=~tasa_ocupacion_nacional, y=~tasa_desempleo_nacional,
                  type="scatter", mode="markers", name="Desempleo vs Ocupacion",
                  marker=list(color=ndq_p_azul, size=5, opacity=.7))
    g2 <- plot_ly(df, x=~tasa_global_participacion_nacional, y=~tasa_desempleo_nacional,
                  type="scatter", mode="markers", name="Desempleo vs Participacion",
                  marker=list(color=ndq_p_verde, size=5, opacity=.7))
    g3 <- plot_ly(df, x=~tasa_desempleo_area, y=~tasa_desempleo_nacional,
                  type="scatter", mode="markers", name="Area vs Nacional",
                  marker=list(color=ndq_p_rojo, size=5, opacity=.7))
    subplot(g1,g2,g3, nrows=3, shareX=FALSE, titleX=TRUE, titleY=TRUE) %>%
      layout(title=list(text="Graficos de dispersion por pares",
                        font=list(color=ndq_text,size=14)),
             paper_bgcolor=ndq_bg, plot_bgcolor=ndq_bg,
             font=list(color=ndq_text),
             margin=list(t=50,r=20,b=40,l=50))
  })
  
  output$evolucion <- renderPlotly({
    p <- plot_ly(mlc_f()) %>%
      add_lines(x=~fecha, y=~tasa_desempleo_nacional,
                name="Desempleo", line=list(color=ndq_p_rojo,width=2)) %>%
      add_lines(x=~fecha, y=~tasa_ocupacion_nacional,
                name="Ocupacion", line=list(color=ndq_p_azul,width=2)) %>%
      layout(
        shapes=list(list(type="rect",x0="2020-01-01",x1="2021-06-01",y0=0,y1=1,
                         xref="x",yref="paper",fillcolor=ndq_gray,opacity=.08,line=list(width=0))),
        annotations=list(list(x="2020-04-01",y=.95,xref="x",yref="paper",
                              text="COVID-19",showarrow=FALSE,font=list(color=ndq_gray,size=11)))
      )
    plotly_layout(p,"Evolucion Temporal: Desempleo vs Ocupacion Nacional")
  })
  
  output$box_anual_des <- renderPlotly({
    p <- mlc_f() %>% mutate(ano=factor(year(fecha))) %>%
      plot_ly(x=~ano, y=~tasa_desempleo_nacional, type="box",
              marker=list(color=ndq_p_rojo,size=3),
              line=list(color=ndq_p_rojo,width=1.5),
              fillcolor=paste0(ndq_p_rojo,"44"))
    plotly_layout(p,"Desempleo - Distribucion anual")
  })
  
  output$box_anual_ocu <- renderPlotly({
    p <- mlc_f() %>% mutate(ano=factor(year(fecha))) %>%
      plot_ly(x=~ano, y=~tasa_ocupacion_nacional, type="box",
              marker=list(color=ndq_p_azul,size=3),
              line=list(color=ndq_p_azul,width=1.5),
              fillcolor=paste0(ndq_p_azul,"44"))
    plotly_layout(p,"Ocupacion - Distribucion anual")
  })
  
  output$mariposa <- renderPlotly({
    df <- mlc_f() %>%
      mutate(ano = year(fecha)) %>%
      group_by(ano) %>%
      summarise(des_area=round(mean(tasa_desempleo_area),2),
                des_nal=round(mean(tasa_desempleo_nacional),2),
                .groups="drop")
    plot_ly() %>%
      add_trace(data=df, x=~-des_area, y=~factor(ano), type="bar", orientation="h",
                name="Desempleo 13 Areas", marker=list(color=ndq_p_rojo, opacity=.85),
                hovertemplate="<b>%{y}</b><br>Desempleo Areas: %{customdata:.1f}%<extra></extra>",
                customdata=~des_area) %>%
      add_trace(data=df, x=~des_nal, y=~factor(ano), type="bar", orientation="h",
                name="Desempleo Nacional", marker=list(color=ndq_p_azul, opacity=.85),
                hovertemplate="<b>%{y}</b><br>Desempleo Nacional: %{x:.1f}%<extra></extra>") %>%
      layout(barmode="overlay",
             title=list(text="Comparacion anual: 13 Areas (<-) vs Nacional (->)",
                        font=list(color=ndq_text,size=14,family="Inter")),
             paper_bgcolor=ndq_bg, plot_bgcolor=ndq_bg,
             font=list(color=ndq_text,family="Inter"),
             xaxis=list(title="<- Areas  |  Nacional ->",
                        tickvals=c(-20,-15,-10,-5,0,5,10,15,20),
                        ticktext=c("20","15","10","5","0","5","10","15","20"),
                        gridcolor=ndq_grid, zerolinecolor="#0a0e1a", zerolinewidth=2,
                        tickfont=list(color=ndq_sub,size=11)),
             yaxis=list(title="",tickfont=list(color=ndq_sub,size=11)),
             legend=list(orientation="h",y=-0.12,font=list(size=12)),
             margin=list(t=60,r=30,b=80,l=60),
             shapes=list(list(type="line",x0=0,x1=0,y0=0,y1=1,
                              xref="x",yref="paper",line=list(color="#0a0e1a",width=2))))
  })
  
  output$linea_tiempo <- renderPlotly({
    req(input$vars_linea)
    df   <- mlc_f()
    cols <- input$vars_linea
    names_map <- c(
      tasa_desempleo_nacional            = "Desempleo Nacional",
      tasa_desempleo_area                = "Desempleo 13 Areas",
      tasa_ocupacion_nacional            = "Ocupacion Nacional",
      tasa_ocupacion_area                = "Ocupacion 13 Areas",
      tasa_global_participacion_nacional = "Participacion Nal.",
      tasa_global_participacion_area     = "Participacion Area"
    )
    colores_map <- c(
      tasa_desempleo_nacional            = ndq_p_rojo,
      tasa_desempleo_area                = "#e8a0a0",
      tasa_ocupacion_nacional            = ndq_p_azul,
      tasa_ocupacion_area                = ndq_p_cielo,
      tasa_global_participacion_nacional = ndq_p_verde,
      tasa_global_participacion_area     = "#80c9a0"
    )
    p <- plot_ly()
    for (col in cols) {
      p <- p %>% add_lines(data=df, x=~fecha, y=as.formula(paste0("~",col)),
                           name=names_map[col], line=list(color=colores_map[col],width=2),
                           hovertemplate=paste0("<b>%{x|%b %Y}</b><br>",names_map[col],": %{y:.1f}%<extra></extra>"))
    }
    p %>% layout(
      title=list(text="Series seleccionadas - periodo filtrado",
                 font=list(color=ndq_text,size=14,family="Inter")),
      paper_bgcolor=ndq_bg, plot_bgcolor=ndq_bg,
      font=list(color=ndq_text,family="Inter"),
      xaxis=list(gridcolor=ndq_grid, zerolinecolor=ndq_grid,
                 tickfont=list(color=ndq_sub,size=11),
                 rangeslider=list(visible=TRUE,thickness=0.06),
                 rangeselector=list(
                   buttons=list(
                     list(count=1,  label="1A",  step="year", stepmode="backward"),
                     list(count=5,  label="5A",  step="year", stepmode="backward"),
                     list(count=10, label="10A", step="year", stepmode="backward"),
                     list(step="all",label="Todo")),
                   bgcolor="#f0f7ff", activecolor=ndq_p_azul,
                   font=list(color=ndq_text,size=11))),
      yaxis=list(gridcolor=ndq_grid, zerolinecolor=ndq_grid,
                 tickfont=list(color=ndq_sub,size=11), ticksuffix="%"),
      legend=list(orientation="h",y=-0.25,font=list(size=12)),
      margin=list(t=50,r=20,b=80,l=50),
      shapes=list(list(type="rect",x0="2020-01-01",x1="2021-06-01",y0=0,y1=1,
                       xref="x",yref="paper",fillcolor=ndq_gray,opacity=.07,line=list(width=0))),
      annotations=list(list(x="2020-07-01",y=.97,xref="x",yref="paper",
                            text="COVID-19",showarrow=FALSE,font=list(color=ndq_gray,size=10)))
    )
  })
  
  output$info_variable <- renderUI({
    req(input$var)
    contenido <- switch(input$var,
                        "tgp_area" = list(titulo="TGP - 13 areas",      texto="Mide la participacion laboral en zonas urbanas."),
                        "tgp_nal"  = list(titulo="TGP - Nacional",       texto="Refleja la participacion laboral total del pais."),
                        "des_area" = list(titulo="Desempleo - 13 areas", texto="Proporcion de personas que buscan empleo en ciudades."),
                        "des_nal"  = list(titulo="Desempleo - Nacional",  texto="Nivel general de desempleo del pais. Variable objetivo del modelo."),
                        "ocu_area" = list(titulo="Ocupacion - 13 areas",  texto="Nivel de empleo efectivo en zonas urbanas."),
                        "ocu_nal"  = list(titulo="Ocupacion - Nacional",   texto="Nivel general de empleo en Colombia.")
    )
    tags$div(class="info-panel", h4(contenido$titulo), p(contenido$texto))
  })
  
  output$tabla_adf <- renderDT({
    data.frame(
      Variable=c("participacion_area","participacion_nacional","desempleo_area",
                 "desempleo_nacional","ocupacion_area","ocupacion_nacional"),
      p_value=round(c(adf.test(MLC$tasa_global_participacion_area)$p.value,
                      adf.test(MLC$tasa_global_participacion_nacional)$p.value,
                      adf.test(MLC$tasa_desempleo_area)$p.value,
                      adf.test(MLC$tasa_desempleo_nacional)$p.value,
                      adf.test(MLC$tasa_ocupacion_area)$p.value,
                      adf.test(MLC$tasa_ocupacion_nacional)$p.value),4)
    ) %>%
      mutate(Estacionaria=ifelse(p_value<.05,"Si","No")) %>%
      datatable(options=list(pageLength=10), class="display compact stripe")
  })
  
  output$descomposicion <- renderPlot({
    ts_var <- ts(MLC$tasa_desempleo_nacional,frequency=12)
    autoplot(decompose(ts_var,type="multiplicative")) +
      ggtitle("Descomposicion Clasica Multiplicativa - Desempleo Nacional") +
      theme_minimal(base_size=12) +
      theme(plot.background=element_rect(fill="white",color=NA),
            panel.background=element_rect(fill="white",color=NA),
            panel.grid.major=element_line(color="#e8ecf0"),
            panel.grid.minor=element_blank(),
            plot.title=element_text(color=ndq_text,size=14,face="bold"),
            axis.text=element_text(color=ndq_sub),
            strip.text=element_text(color=ndq_blue,face="bold"))
  })
  
  output$acf_pacf <- renderPlot({
    ts_var <- ts(MLC$tasa_desempleo_nacional,frequency=12)
    ggtsdisplay(ts_var, main="Serie, ACF y PACF - Desempleo Nacional") +
      theme_minimal(base_size=12)
  })
}
dashboardPage(
  skin = "blue",
  
  dashboardHeader(
    title = tags$span(tags$b("MERCADO LABORAL"), tags$span("COL", class="ndq-badge"))
  ),
  
  dashboardSidebar(
    tags$div(style="padding:16px 15px 6px;font-size:10px;font-weight:700;
                    color:#4a5568;text-transform:uppercase;letter-spacing:2px;","Navegacion"),
    sidebarMenu(
      menuItem("Componentes",    tabName="secciones",    icon=icon("book-open")),
      menuItem("EDA",            tabName="eda",          icon=icon("chart-bar")),
      menuItem("Conclusiones",   tabName="conclusiones", icon=icon("circle-check")),
      menuItem("Referencias",    tabName="referencias",  icon=icon("file-lines"))
    ),
    tags$div(class="sidebar-info",
             icon("database"), " DANE / Banco de la Republica", tags$br(),
             icon("calendar"), " Ene 2001 - Dic 2025",          tags$br(),
             icon("hashtag"),  " 300 observaciones mensuales"
    ),
    tags$hr(style="border-color:#1e2a3a;margin:10px 0;"),
    tags$div(style="font-size:10px;color:#8899aa;padding:0 15px 10px;",
             "Autores: S. Hurtado & A. Parejo")
  ),
  
  dashboardBody(
    tags$head(
      tags$link(rel="icon", type="image/svg+xml", href="data:image/svg+xml,
        <svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 3 2'>
          <rect width='3' height='2' fill='%23FCD116'/>
          <rect width='3' height='1' y='1' fill='%23003893'/>
          <rect width='3' height='.5' y='1.5' fill='%23CE1126'/>
        </svg>"),
      tags$style(HTML(css_main)),
      tags$link(rel="stylesheet",
                href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap"),
      tags$script(HTML(js_contador)),
      tags$script(HTML(js_acordeon)),
      tags$script(HTML(js_interp)),
      tags$script(HTML(js_resumen_def))
    ),
    
    tags$div(class="filtro-global-box",
             tags$span(icon("sliders"), class="filtro-titulo", " Filtro de periodo"),
             dateRangeInput("rango_fecha", label=NULL,
                            start=as.Date("2001-01-01"), end=as.Date("2025-12-01"),
                            min=as.Date("2001-01-01"),   max=as.Date("2025-12-01"),
                            format="M yyyy", language="es", separator=" a "),
             tags$span(style="color:#aab4c8;font-size:12px;margin-left:auto;",
                       icon("circle-info"), " El filtro aplica a todas las visualizaciones del EDA")
    ),
    
    tabItems(
      
      tabItem(tabName="secciones",
              tabBox(width=12,
                     
                     tabPanel("Introduccion",
                              h3("Introduccion"), tags$hr(class="ndq-divider"),
                              p("El mercado laboral constituye uno de los principales indicadores del desempeno economico de un pais, ya que refleja la capacidad de la economia de generar empleo. Su analisis permite comprender la interaccion entre la oferta laboral y la demanda de trabajo, asi como evaluar el funcionamiento general de la economia en terminos de produccion y generacion de ingresos."),
                              p("Este seguimiento se realiza a partir de la Gran Encuesta Integrada de Hogares (GEIH), elaborada por el Departamento Administrativo Nacional de Estadistica (DANE). El analisis de estos indicadores resulta fundamental no solo para describir el mercado laboral, sino para identificar tendencias, posibles desequilibrios y ciclos."),
                              p("El presente proyecto analiza el comportamiento del mercado laboral colombiano a partir de indicadores mensuales publicados por el Banco de la Republica y producidos por el DANE, para el periodo comprendido entre enero de 2001 y diciembre de 2025."),
                              tags$hr(class="ndq-divider"),
                              h4("Variables analizadas"),
                              tags$div(class="var-accordion",
                                       acc_item("tgp_area","acc-tgp-area","users","Tasa Global de Participacion - 13 areas","TGP AREA","badge-azul",
                                                list(tagList(tags$b("Definicion:")," Relacion porcentual entre la poblacion que integra la fuerza de trabajo y la PET en las 13 principales areas metropolitanas."),
                                                     tagList(tags$b("Tipo:")," Cuantitativa continua."),
                                                     tagList(tags$b("Escala:")," Razon."),
                                                     tagList(tags$b("Unidad:"), " %."),
                                                     tagList(tags$b("Frecuencia:"), "Mensual."),
                                                     tagList(tags$b("Interpretacion:")," Mide la participacion laboral en zonas urbanas, reflejando la presion de la poblacion sobre el mercado de trabajo."))),
                                       acc_item("tgp_nal","acc-tgp-nal","globe","Tasa Global de Participacion - Nacional","TGP NAL","badge-azul",
                                                list(tagList(tags$b("Definicion:")," Relacion entre la fuerza laboral y la PET a nivel nacional."),
                                                     tagList(tags$b("Tipo:")," Cuantitativa continua."),
                                                     tagList(tags$b("Escala:")," Razon."),
                                                     tagList(tags$b("Unidad:"), " %."),
                                                     tagList(tags$b("Frecuencia:"), "Mensual"),
                                                     tagList(tags$b("Interpretacion:")," Evalua la participacion laboral agregada del pais, incluyendo zonas urbanas y rurales."))),
                                       acc_item("des_area","acc-des-area","person-walking-arrow-right","Tasa de Desempleo - 13 areas","TD AREA","badge-rojo",
                                                list(tagList(tags$b("Definicion:")," Proporcion de desocupados sobre la fuerza laboral en las 13 principales areas metropolitanas."),
                                                     tagList(tags$b("Tipo:")," Cuantitativa continua."),
                                                     tagList(tags$b("Escala:")," Razon."),
                                                     tagList(tags$b("Unidad:"), " %."),
                                                     tagList(tags$b("Frecuencia:"), "Mensual."),
                                                     tagList(tags$b("Interpretacion:")," Indica el nivel de desempleo en los principales centros urbanos del pais."))),
                                       acc_item("des_nal","acc-des-nal","arrow-trend-up","Tasa de Desempleo - Nacional","TD NAL","badge-rojo",
                                                list(tagList(tags$b("Definicion:")," Proporcion de desocupados sobre la fuerza laboral a nivel nacional."),
                                                     tagList(tags$b("Tipo:")," Cuantitativa continua."),
                                                     tagList(tags$b("Escala:")," Razon."),
                                                     tagList(tags$b("Unidad:"), " %."),
                                                     tagList(tags$b("Frecuencia:"), "Mensual."),
                                                     tagList(tags$b("Interpretacion:")," Variable objetivo del estudio. Refleja el desempleo total capturando diferencias entre regiones urbanas y rurales."))),
                                       acc_item("ocu_area","acc-ocu-area","briefcase","Tasa de Ocupacion - 13 areas","TO AREA","badge-verde",
                                                list(tagList(tags$b("Definicion:")," Proporcion de ocupados sobre la PET en las 13 principales areas metropolitanas."),
                                                     tagList(tags$b("Tipo:")," Cuantitativa continua."),
                                                     tagList(tags$b("Escala:")," Razon."),
                                                     tagList(tags$b("Unidad:"), " %."),
                                                     tagList(tags$b("Frecuencia:"), "Mensual."),
                                                     tagList(tags$b("Interpretacion:")," Mide el nivel de empleo efectivo en las principales ciudades del pais."))),
                                       acc_item("ocu_nal","acc-ocu-nal","chart-line","Tasa de Ocupacion - Nacional","TO NAL","badge-verde",
                                                list(tagList(tags$b("Definicion:")," Proporcion de ocupados sobre la PET a nivel nacional."),
                                                     tagList(tags$b("Tipo:")," Cuantitativa continua."),
                                                     tagList(tags$b("Escala:")," Razon."),
                                                     tagList(tags$b("Unidad:"), " %."),
                                                     tagList(tags$b("Frecuencia:"), "Mensual."),
                                                     tagList(tags$b("Interpretacion:")," Evalua el nivel general de empleo en Colombia y permite compararlo con las areas urbanas.")))
                              ),
                              tags$hr(class="ndq-divider"),
                              tags$div(class="highlight-box",
                                       tags$b(style="color:#0066cc;",icon("circle-question")," Pregunta de investigacion"),
                                       tags$br(),tags$br(),
                                       p("Como ha evolucionado la tasa de desempleo en Colombia a lo largo del tiempo y que relacion presenta con otros indicadores del mercado laboral como la tasa de ocupacion y la tasa global de participacion?")
                              )
                     ),
                     
                     tabPanel("Justificacion",
                              h3("Justificacion"), tags$hr(class="ndq-divider"),
                              p("El mercado laboral colombiano ha experimentado transformaciones marcadas por periodos de recuperacion economica, reformas estructurales y choques economicos como la pandemia de COVID-19. A pesar de que el DANE publica periodicamente los principales indicadores laborales, no siempre existe un analisis integrado y de largo plazo que permita comprender su dinamica conjunta."),
                              p("Este proyecto se justifica por la necesidad de contar con una vision analitica, basada en datos, sobre el periodo 2001-2025."),
                              p("Desde una perspectiva de politica economica, este analisis resulta clave para orientar decisiones en materia de empleo, formacion laboral y diseno de programas sociales, combinando estadistica rigurosa con visualizaciones claras y accesibles.")
                     ),
                     
                     tabPanel("Objetivos",
                              h3("Objetivos"), tags$hr(class="ndq-divider"),
                              h4("Objetivo general"),
                              tags$div(class="highlight-box",
                                       p("Analizar la evolucion de la tasa de desempleo en Colombia a lo largo del tiempo y su relacion con otros indicadores del mercado laboral, mediante el desarrollo de un dashboard interactivo y la implementacion de un modelo predictivo.")),
                              h4("Objetivos especificos"),
                              tags$ol(
                                tags$li("Explorar y visualizar el comportamiento historico de los indicadores laborales mediante analisis exploratorio de datos."),
                                tags$li("Disenar y desarrollar un dashboard interactivo para analizar dinamicamente la evolucion y relacion entre los indicadores."),
                                tags$li("Implementar y evaluar un modelo predictivo para estimar la evolucion de la tasa de desempleo."))
                     ),
                     
                     tabPanel("Marco Teorico",
                              h3("Marco Teorico"), tags$hr(class="ndq-divider"),
                              p("El mercado laboral se define como el espacio economico en el que interactuan la oferta y la demanda de trabajo. El salario actua como mecanismo de ajuste: cuando la demanda supera la oferta, los salarios suben incentivando mayor participacion; cuando ocurre lo contrario, surge el desempleo (Mankiw, 2015). Sin embargo, este ajuste rara vez es inmediato dado que existen fricciones institucionales que distorsionan el equilibrio."),
                              p("El DANE utiliza las definiciones de la OIT. La PET se divide en PEA e inactiva. La PEA se subdivide en ocupados y desocupados, originando los tres indicadores centrales del estudio."),
                              p("Desde el enfoque de series de tiempo, el mercado laboral presenta tendencias de largo plazo, ciclos economicos y estacionalidad. Para su analisis riguroso se emplean modelos ARIMA y enfoques de machine learning (Hyndman & Athanasopoulos, 2021)."),
                              p("En Colombia, Arango, Herrera y Posada (2008) documentaron la persistencia del desempleo y la importancia de factores institucionales. El periodo 2020-2021 constituye una ruptura estructural que cualquier modelo predictivo debe considerar.")
                     ),
                     
                     tabPanel("Hipotesis",
                              h3("Hipotesis"), tags$hr(class="ndq-divider"),
                              h4("Hipotesis principal"),
                              tags$div(class="highlight-box",
                                       p("La tasa de desempleo nacional presenta una relacion inversa y estadisticamente significativa con la tasa de ocupacion y la TGP, con patrones ciclicos y estacionales modelables a partir de su comportamiento historico.")),
                              h4("Hipotesis secundarias"),
                              tags$ol(
                                tags$li("El desempleo en las 13 areas es un predictor consistente del desempleo nacional, dada la alta correlacion estructural entre ambas series."),
                                tags$li("El choque del COVID-19 en 2020 constituye una ruptura estructural diferenciable estadisticamente del comportamiento historico previo."),
                                tags$li("La variabilidad estacional del desempleo es un componente recurrente y modelable dentro de la serie historica."))
                     ),
                     
                     tabPanel("Metodologia",
                              h3("Metodologia"), tags$hr(class="ndq-divider"),
                              p("El estudio adopta un enfoque cuantitativo enmarcado en la metodologia de series de tiempo, donde el orden cronologico de las observaciones es fundamental para el modelado."),
                              tags$hr(class="ndq-divider"),
                              h4("Fases del proyecto"),
                              fluidRow(
                                column(4,tags$div(class="fase-card",tags$span("01",class="fase-num"),tags$span("EDA",class="fase-titulo"),
                                                  tags$span("Analisis univariado y bivariado de los indicadores del mercado laboral.",class="fase-desc"))),
                                column(4,tags$div(class="fase-card",tags$span("02",class="fase-num"),tags$span("Dashboard",class="fase-titulo"),
                                                  tags$span("Visualizacion interactiva en Shiny con los patrones identificados.",class="fase-desc"))),
                                column(4,tags$div(class="fase-card",tags$span("03",class="fase-num"),tags$span("Modelado",class="fase-titulo"),
                                                  tags$span("Modelo predictivo.",class="fase-desc")))
                              ),
                              tags$hr(class="ndq-divider"),
                              h4("Variables del proyecto - haz clic para explorar"),
                              fluidRow(
                                column(4,tags$div(class="var-card blue1",onclick="Shiny.setInputValue('var','tgp_area')",
                                                  tags$div(class="var-title","Participacion"),tags$div(class="var-sub","TGP - 13 areas"))),
                                column(4,tags$div(class="var-card blue2",onclick="Shiny.setInputValue('var','tgp_nal')",
                                                  tags$div(class="var-title","Participacion"),tags$div(class="var-sub","TGP - Nacional"))),
                                column(4,tags$div(class="var-card red1",onclick="Shiny.setInputValue('var','des_area')",
                                                  tags$div(class="var-title","Desempleo"),tags$div(class="var-sub","13 areas")))
                              ),
                              fluidRow(
                                column(4,tags$div(class="var-card red2",onclick="Shiny.setInputValue('var','des_nal')",
                                                  tags$div(class="var-title","Desempleo"),tags$div(class="var-sub","Nacional"))),
                                column(4,tags$div(class="var-card green1",onclick="Shiny.setInputValue('var','ocu_area')",
                                                  tags$div(class="var-title","Ocupacion"),tags$div(class="var-sub","13 areas"))),
                                column(4,tags$div(class="var-card green2",onclick="Shiny.setInputValue('var','ocu_nal')",
                                                  tags$div(class="var-title","Ocupacion"),tags$div(class="var-sub","Nacional")))
                              ),
                              uiOutput("info_variable"),
                              tags$hr(class="ndq-divider"),
                              h4("Herramientas"),
                              tags$ul(
                                tags$li("RStudio - analisis estadistico y modelado"),
                                tags$li("Python - analisis complementario"),
                                tags$li("Shiny - visualizacion interactiva"),
                                tags$li("GitHub - control de versiones"))
                     )
              )
      ),
      
      tabItem(tabName="eda",
              uiOutput("alerta_desempleo"),
              fluidRow(
                column(3,uiOutput("kpi_media")),
                column(3,uiOutput("kpi_min")),
                column(3,uiOutput("kpi_max")),
                column(3,uiOutput("kpi_obs"))
              ),
              tabBox(width=12,
                     
                     tabPanel("Hallazgos clave",
                              h3("Hallazgos clave del periodo"), tags$hr(class="ndq-divider"),
                              uiOutput("hallazgos_ui")
                     ),
                     
                     tabPanel("Inspeccion inicial",
                              h4("Estadisticos descriptivos - todas las variables"), tags$hr(class="ndq-divider"),
                              DTOutput("tabla_desc"), br(),
                              h4("Mapa de datos faltantes"),
                              plotOutput("missmap", height="300px"),
                              interp_card("missmap","El mapa de datos faltantes confirma que el dataset no presenta valores ausentes en ninguna de las seis variables para el periodo completo 2001-2025. Esto garantiza que los analisis estadisticos y los modelos predictivos no requeriran imputacion, lo que fortalece la fiabilidad de los resultados obtenidos.")
                     ),
                     
                     tabPanel("Univariado - Desempleo",
                              h4("Resumen estadistico"), tags$hr(class="ndq-divider"),
                              uiOutput("resumen_desempleo"),
                              br(),
                              fluidRow(
                                column(6,
                                       plotlyOutput("histograma", height="360px"),
                                       interp_card("hist","El histograma presenta la distribucion de frecuencias de la tasa de desempleo nacional. En el eje horizontal se ubican los intervalos de la variable (10, 15 y 20), mientras que el eje vertical muestra la frecuencia de observaciones en cada rango, con un maximo de 20. La altura de las barras permite identificar la concentracion de los datos. Si las frecuencias mas altas se encuentran en los intervalos inferiores (cercanos a 10), predominan tasas de desempleo bajas. Por el contrario, si se concentran en valores superiores (cercanos a 20), predominan tasas altas. Este analisis visual facilita la comprension del comportamiento del desempleo en el periodo estudiado y constituye una base descriptiva fundamental para estudios economicos y sociales.")
                                ),
                                column(6,
                                       plotlyOutput("boxplot", height="360px"),
                                       interp_card("box","Se identifican tres puntos rojos fuera de este rango, lo que indica la presencia de valores atipicos o outliers: uno en el 20%, dos en el 15% y uno en el 10%. Estos valores se desvian del comportamiento general de la serie, posiblemente reflejando periodos con condiciones economicas excepcionales, como crisis o recuperaciones atipicas. Se reflejan unos outliers, pero al ser el dataset economico se mantendra por ahora.")
                                )
                              ),
                              br(),
                              p("Una vez analizada la distribucion de las variables mediante histogramas y detectados posibles valores atipicos con boxplot, se emplea el grafico de dispersion con el fin de visualizar cada observacion individualmente. Este tipo de grafico permite confirmar la presencia de outliers, identificar patrones en los datos y complementar el analisis exploratorio previo."),
                              h4("Dispersion temporal con outliers"),
                              plotlyOutput("dispersion", height="380px"),
                              interp_card("disp","El grafico de dispersion muestra la evolucion temporal de la tasa de desempleo nacional entre 2001 y 2025. La mayoria de los valores se concentran entre 8% y 14%, lo que indica un comportamiento relativamente estable durante gran parte del periodo. No obstante, se identifican valores atipicos, especialmente alrededor del ano 2020, donde el desempleo supera el 20%, reflejando un choque significativo en el mercado laboral asociado al impacto economico de la pandemia de COVID-19. Estos puntos no representan errores en los datos, sino eventos economicos extraordinarios que afectaron temporalmente la dinamica del empleo en el pais.")
                     ),
                     
                     tabPanel("Univariado - Caracteristicas",
                              h4("Estadisticos por variable"), tags$hr(class="ndq-divider"),
                              DTOutput("tabla_caracteristicas"), br(),
                              h4("Boxplots por indicador"),
                              plotlyOutput("boxplots_caracteristicas", height="400px"),
                              interp_card("boxcar","Al analizar los boxplots presentados, observamos que la tasa de desempleo a nivel de area es el indicador con mayor variabilidad y valores mas extremos, con una mediana cercana al 10% y un rango que se extiende hasta cerca del 20%, lo que refleja disparidades significativas en el desempleo local. En contraste, los indicadores de tasa de ocupacion y tasa global de participacion, tanto a nivel de area como nacional, presentan medianas centradas y una dispersion mucho mas contenida. Destaca especialmente que las versiones nacionales de estos indicadores muestran cajas mas estrechas y bigotes mas cortos que sus contrapartes de area, lo que sugiere que, a escala nacional, el mercado laboral tiende a ser mas estable y homogeneo, mientras que a nivel local se experimentan fluctuaciones mas pronunciadas y contextos laborales mas diversos.")
                     ),
                     
                     tabPanel("Bivariado",
                              h4("Matriz de correlaciones"), tags$hr(class="ndq-divider"),
                              p("Despues de analizar cada variable de forma individual y de explorar algunas relaciones mediante graficos de dispersion, resulta util complementar con una matriz de correlacion que ayudara a evaluar de manera conjunta la fuerza y la direccion de la relacion lineal entre los indicadores del mercado laboral."),
                              plotlyOutput("correlacion", height="440px"),
                              interp_card("corr","Al examinar la matriz de correlaciones, se identifican relaciones clave en el mercado laboral. Destaca una alta correlacion positiva entre las tasas de desempleo de area y nacional (0.96), asi como entre las tasas de ocupacion de ambos niveles (0.94), lo que indica que los comportamientos locales y nacionales tienden a moverse de manera sincronizada. Asimismo, la participacion global muestra una fuerte consistencia entre el area y la nacion (0.95). Por otro lado, se observa una correlacion negativa significativa entre la tasa de desempleo y la tasa de ocupacion (aproximadamente -0.80 en ambos niveles), lo que refleja la relacion inversa esperada: a mayor desempleo, menor ocupacion. Finalmente, la participacion global presenta una correlacion moderada a alta con la ocupacion (alrededor de 0.80), sugiriendo que una mayor participacion en el mercado laboral se asocia con mayores niveles de ocupacion, aunque su relacion con el desempleo es debil y negativa."),
                              br(),
                              h4("Dispersion por pares"),
                              plotlyOutput("pares", height="680px"),
                              interp_card("pares","Al analizar las relaciones graficas entre los indicadores del mercado laboral, se observan patrones claros y consistentes con la teoria economica. En el primer grafico, Desempleo vs Ocupacion Nacional, se aprecia una clara relacion inversa: a medida que aumenta la tasa de ocupacion (TON), la tasa de desempleo nacional (TDN) tiende a disminuir, con puntos que oscilan entre aproximadamente 45% y 65% de ocupacion y desempleo que va del 20% a valores cercanos a cero. En el segundo grafico, Desempleo vs Participacion Nacional, la relacion es menos pronunciada pero tambien negativa. Finalmente, el grafico Desempleo Area vs Nacional confirma una fuerte correlacion positiva, donde los puntos se alinean casi perfectamente en una tendencia lineal ascendente, indicando que el comportamiento del desempleo a nivel local replica fielmente el comportamiento nacional.")
                     ),
                     
                     tabPanel("Evolucion temporal",
                              h4("Desempleo vs Ocupacion Nacional"), tags$hr(class="ndq-divider"),
                              p("Dado que los datos corresponden a observaciones mensuales a lo largo del tiempo, es importante analizar el comportamiento de la variable objetivo desde una perspectiva temporal. Cuando la ocupacion sube el desempleo baja, reflejando el comportamiento inverso del mercado laboral."),
                              plotlyOutput("evolucion", height="400px"),
                              interp_card("evol","Al observar la evolucion temporal del mercado laboral nacional entre los anos 2000 y 2025, se identifican dinamicas inversas y claramente definidas entre el desempleo y la ocupacion. La tasa de desempleo nacional muestra picos pronunciados en periodos de crisis especialmente alrededor de 2010 y nuevamente cerca de 2020, coincidiendo con caidas simultaneas en la tasa de ocupacion nacional, lo que refleja la sensibilidad del empleo ante choques economicos. En contraste, en los periodos de recuperacion, la ocupacion aumenta mientras el desempleo desciende, manteniendo consistentemente la relacion inversa esperada entre ambos indicadores. Esta grafica valida visualmente la correlacion negativa observada en analisis anteriores y permite identificar con claridad los momentos de mayor tension en el mercado laboral a lo largo de las ultimas dos decadas."),
                              br(),
                              h4("Distribucion anual - Desempleo"),
                              plotlyOutput("box_anual_des", height="380px"),
                              interp_card("boxdes","Los boxplots anuales de desempleo muestran una tendencia descendente sostenida desde 2002 hasta 2019, con medianas que pasan de valores cercanos al 18% a niveles por debajo del 10%. La variabilidad intra-anual (tamano de las cajas) se mantiene relativamente estable en ese periodo, reflejando la estacionalidad recurrente del mercado laboral. El ano 2020 rompe drasticamente esta tendencia: la caja se amplia de forma extraordinaria, con valores que superan el 20%, evidenciando el impacto del COVID-19 como choque externo sin precedentes en la serie historica."),
                              br(),
                              h4("Distribucion anual - Ocupacion"),
                              plotlyOutput("box_anual_ocu", height="380px"),
                              interp_card("boxocu","Al observar los graficos en conjunto, el mercado laboral es dinamico, lejos de ser estacionario. A largo plazo, se notan tendencias claras, como la mejora progresiva en la ocupacion hasta 2015 acompanada de variaciones estacionales que suceden todos los anos y se reflejan en el tamano de las cajas. Sin embargo, el quiebre o choque economico se nota en el ano 2020. La pandemia no solo hundio bruscamente los indicadores, sino que genero un nivel de volatilidad alto, ensanchando las cajas a proporciones que en los anteriores anos no se habian visto. El modelo a realizar debera aislar ese choque de la pandemia conteniendo los ciclos anuales para no generar pronosticos sesgados.")
                     ),
                     
                     tabPanel("Mariposa",
                              h4("13 Areas vs Nacional - Grafico de mariposa"), tags$hr(class="ndq-divider"),
                              p("Compara visualmente los indicadores entre las 13 areas metropolitanas (izquierda) y el nivel nacional (derecha). Una brecha amplia indica diferencias estructurales entre zonas urbanas y el resto del pais."),
                              plotlyOutput("mariposa", height="600px"),
                              interp_card("mariposa","El grafico de mariposa permite comparar ano a ano la tasa de desempleo entre las 13 areas metropolitanas y el nivel nacional. En todos los anos analizados, el desempleo en las areas urbanas supera al nacional, lo que confirma la concentracion estructural del desempleo en los principales centros urbanos del pais. La brecha es mas pronunciada en los anos de mayor crisis (2002-2003 y 2020), cuando las ciudades absorbieron con mayor intensidad el impacto de los choques economicos. A partir de 2021, ambas barras tienden a converger, reflejando una recuperacion gradual y sincronizada entre zonas urbanas y el agregado nacional.")
                     ),
                     
                     tabPanel("Linea de tiempo",
                              h4("Explorador interactivo de series"), tags$hr(class="ndq-divider"),
                              p("Usa el slider para navegar por periodos especificos. Selecciona los indicadores que quieres comparar."),
                              checkboxGroupInput("vars_linea", label=NULL,
                                                 choices=c("Desempleo Nacional"="tasa_desempleo_nacional",
                                                           "Desempleo 13 Areas"="tasa_desempleo_area",
                                                           "Ocupacion Nacional"="tasa_ocupacion_nacional",
                                                           "Ocupacion 13 Areas"="tasa_ocupacion_area",
                                                           "Participacion Nal."="tasa_global_participacion_nacional",
                                                           "Participacion Area"="tasa_global_participacion_area"),
                                                 selected=c("tasa_desempleo_nacional","tasa_ocupacion_nacional"),
                                                 inline=TRUE),
                              plotlyOutput("linea_tiempo", height="450px"),
                              interp_card("linea","El explorador de series permite analizar dinamicamente la evolucion conjunta de los indicadores del mercado laboral. Al seleccionar desempleo y ocupacion nacional, se confirma visualmente la relacion inversa entre ambas variables a lo largo de todo el periodo. El rango deslizable facilita el analisis de subperiodos especificos, como la recuperacion post-COVID (2021-2023) o la fase de estabilizacion pre-pandemia (2015-2019). La zona sombreada marca el periodo de choque estructural de 2020-2021, util como referencia para cualquier analisis comparativo.")
                     ),
                     
                     tabPanel("Series de tiempo",
                              h4("Prueba ADF - Resultados"), tags$hr(class="ndq-divider"),
                              p("La prueba ADF se aplico sobre la tasa de desempleo nacional. Las correlaciones superiores a 0.94 entre series de area y nacional hacen innecesaria la verificacion individual."),
                              DTOutput("tabla_adf"),
                              interp_card("adf","Los resultados de la prueba Dickey-Fuller Aumentada indican que la tasa de desempleo nacional no es estacionaria en niveles, dado que el p-valor supera el umbral de significancia del 5%. Esto implica que la serie presenta una raiz unitaria y que su media y varianza no son constantes a lo largo del tiempo. Por esta razon, antes de modelar se requiere aplicar al menos una diferenciacion regular para estabilizar la media de la serie, lo que orienta el analisis hacia un modelo de la familia ARIMA con d=1."),
                              br(),
                              h4("Descomposicion Clasica Multiplicativa"),
                              plotOutput("descomposicion", height="500px"),
                              interp_card("decomp","En el grafico se puede ver que la serie refleja una tendencia decreciente por un choque el cual fue del ano 2020 por la pandemia, con un patron estacional claro y residuos que se comportan bien, excepto durante ese ano. A su vez, el modelo a realizar debe contemplar la estacionalidad y considerar ese ano."),
                              br(),
                              h4("Serie, ACF y PACF"),
                              plotOutput("acf_pacf", height="440px"),
                              interp_card("acfpacf","La ACF confirma la no estacionariedad con un decaimiento lento. La PACF tiene una caida en el primer rezago, lo que sugiere que una vez se controle ese efecto, la mayor parte de la serie quedara explicada, aunque la estacionalidad sigue siendo relevante. Esto requiere una diferenciacion, orientando el modelo hacia ARIMA. La descomposicion clasica multiplicativa, las pruebas ACF y PACF, y la prueba de Dickey-Fuller aumentada se aplicaron exclusivamente sobre la tasa de desempleo nacional debido a que esta es la variable objetivo del estudio. Las correlaciones superiores a 0.94 evidenciadas entre los indicadores de area y nacional refuerzan la decision de centrar el analisis en la variable que guia el modelado.")
                     )
              )
      ),
      
      tabItem(tabName="conclusiones",
              box(width=12, title="Conclusiones",
                  tags$hr(class="ndq-divider"),
                  p("A partir del analisis exploratorio de los indicadores del mercado laboral en Colombia para el periodo 2001-2025, se observa que la tasa de desempleo nacional presenta un comportamiento relativamente estable con valores concentrados entre el 8% y el 14%. El analisis temporal identifica episodios de alta volatilidad asociados a choques economicos importantes; en particular, en 2020 el desempleo supera el 20%, reflejando el impacto de la pandemia de COVID-19."),
                  tags$hr(class="ndq-divider"),
                  p("Los histogramas y diagramas de caja evidenciaron una dispersion moderada y la presencia de valores atipicos que no corresponden a errores, sino a periodos extraordinarios en la economia colombiana. Por esta razon, se decidio conservarlos dentro del analisis, ya que aportan informacion relevante sobre la dinamica real del mercado laboral."),
                  tags$hr(class="ndq-divider"),
                  p("Por otro lado, el analisis de las variables caracteristicas mostro que los indicadores de participacion y ocupacion presentan una variabilidad relativamente menor en comparacion con las tasas de desempleo. Esto sugiere que, aunque el nivel de participacion y ocupacion de la poblacion tiende a mantenerse dentro de ciertos rangos estables, el desempleo puede experimentar fluctuaciones mas pronunciadas ante cambios en el contexto economico."),
                  tags$hr(class="ndq-divider"),
                  p("El analisis bivariado permitio identificar relaciones claras entre los indicadores del mercado laboral. En particular, se observo una fuerte relacion negativa entre la tasa de desempleo y la tasa de ocupacion, lo cual coincide con la logica economica: a medida que aumenta el numero de personas ocupadas, la proporcion de personas desempleadas tiende a disminuir. Asimismo, la matriz de correlacion evidencio una alta correspondencia entre las tasas calculadas para las principales areas metropolitanas y las tasas a nivel nacional."),
                  tags$hr(class="ndq-divider"),
                  p("Los graficos de dispersion tambien permitieron visualizar estas relaciones de forma clara, confirmando la relacion inversa entre desempleo y ocupacion, asi como la fuerte relacion positiva entre las tasas de desempleo de area y nacional. Estos resultados sugieren que el comportamiento del desempleo en las principales areas urbanas constituye un buen indicador del comportamiento general del mercado laboral colombiano."),
                  tags$hr(class="ndq-divider"),
                  p("En conjunto, el analisis exploratorio permitio comprender la estructura del conjunto de datos, identificar patrones relevantes, detectar valores atipicos y analizar las relaciones existentes entre los principales indicadores laborales. La descomposicion multiplicativa y las pruebas ACF/PACF confirmaron la no estacionariedad y la estacionalidad anual, orientando el modelado hacia un esquema ", tags$b("SARIMA."))
              )
      ),
      
      tabItem(tabName="referencias",
              box(width=12, title="Referencias",
                  tags$hr(class="ndq-divider"),
                  tags$ul(style="line-height:2.4;",
                          tags$li("Arango, L., Herrera, P., & Posada, C. (2008). ",tags$i("Ensayos sobre Politica Economica, 26"),"(56), 204-263."),
                          tags$li("Banco de la Republica de Colombia. (s. f.). ",tags$a(href="https://www.banrep.gov.co",target="_blank",style="color:#0066cc;","Series estadisticas historicas: Mercado laboral.")),
                          tags$li("Congreso de la Republica de Colombia. (1945). ",tags$i("Ley 6 de 1945.")),
                          tags$li("DANE. (s. f.). ",tags$a(href="https://www.dane.gov.co/index.php/estadisticas-por-tema/mercado-laboral/empleo-y-desempleo/geih-historicos",target="_blank",style="color:#0066cc;","GEIH: Empleo y desempleo - historicos.")),
                          tags$li("Hyndman, R. J., & Athanasopoulos, G. (2021). ",tags$i("Forecasting: Principles and practice")," (3rd ed.). ",tags$a(href="https://otexts.com/fpp3/",target="_blank",style="color:#0066cc;","otexts.com/fpp3")),
                          tags$li("Mankiw, N. G. (2015). ",tags$i("Principles of economics")," (8th ed.). Cengage Learning."),
                          tags$li("Mincer, J. (1962). Labor force participation of married women. En H. G. Lewis (Ed.), ",tags$i("Aspects of labor economics")," (pp. 63-105). Princeton University Press.")
                  )
              )
      )
    )
  )
)
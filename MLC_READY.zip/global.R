library(shiny)
library(shinydashboard)
library(tidyverse)
library(lubridate)
library(readxl)
library(corrplot)
library(forecast)
library(tseries)
library(Amelia)
library(DT)
library(plotly)

MLC <- read_excel(
  "C:/Users/elfue/Downloads/MLC.xlsx",
  sheet     = "Series de datos",
  col_types = c("date", "numeric", "numeric",
                "numeric", "numeric", "numeric", "numeric")
)

UMBRAL_ALERTA <- 12
FECHA_MIN     <- min(MLC$fecha)
FECHA_MAX     <- max(MLC$fecha)

ndq_blue   <- "#0066cc"
ndq_green  <- "#00a854"
ndq_red    <- "#e03131"
ndq_gray   <- "#6b7280"
ndq_bg     <- "#ffffff"
ndq_grid   <- "#e8ecf0"
ndq_text   <- "#1a1a2e"
ndq_sub    <- "#6b7280"

ndq_p_azul   <- "#a3c4f4"
ndq_p_rojo   <- "#f4a3a3"
ndq_p_verde  <- "#a3e4c4"
ndq_p_naranj <- "#f4cda3"
ndq_p_lilas  <- "#c4a3f4"
ndq_p_cielo  <- "#a3d8f4"

plotly_layout <- function(p, titulo = "") {
  p %>% layout(
    title         = list(text = titulo, font = list(color = ndq_text, size = 14, family = "Inter")),
    paper_bgcolor = ndq_bg,
    plot_bgcolor  = ndq_bg,
    font          = list(color = ndq_text, family = "Inter, Segoe UI, Arial"),
    xaxis         = list(gridcolor = ndq_grid, zerolinecolor = ndq_grid,
                         tickfont  = list(color = ndq_sub, size = 11)),
    yaxis         = list(gridcolor = ndq_grid, zerolinecolor = ndq_grid,
                         tickfont  = list(color = ndq_sub, size = 11),
                         ticksuffix = "%"),
    legend        = list(font = list(color = ndq_text, size = 12), bgcolor = "rgba(0,0,0,0)"),
    margin        = list(t = 50, r = 20, b = 40, l = 50)
  )
}

acc_item <- function(id, header_class, icon_name, titulo, badge_text, badge_class, items) {
  tags$div(class = "var-acc-item",
           tags$div(class = paste("var-acc-header", header_class), id = paste0("hdr_", id),
                    tags$span(icon(icon_name), " ", titulo,
                              tags$span(badge_text, class = paste("var-badge", badge_class))),
                    tags$span("+", class = "acc-icon")),
           tags$div(class = "var-acc-body", id = paste0("bdy_", id),
                    tags$ul(lapply(items, function(x) tags$li(x)))))
}

interp_card <- function(card_id, texto) {
  tags$div(class = "interp-toggle-wrap",
           tags$div(class = "interp-toggle-btn",
                    id = paste0("itbtn_", card_id),
                    onclick = paste0("toggleInterp('", card_id, "')"),
                    icon("lightbulb"),
                    tags$span(" Ver interpretacion"),
                    tags$span(class = "interp-arrow", id = paste0("itarr_", card_id), "v")
           ),
           tags$div(class = "interp-toggle-body", id = paste0("itbody_", card_id),
                    tags$p(texto)
           )
  )
}

js_contador <- "
function animarContador(el, fin, sufijo, decimales, duracion) {
  var startTime = null;
  function step(ts) {
    if (!startTime) startTime = ts;
    var p = Math.min((ts - startTime) / duracion, 1);
    var ease = 1 - Math.pow(1 - p, 3);
    el.textContent = (fin * ease).toFixed(decimales) + sufijo;
    if (p < 1) requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
}
$(document).on('shiny:value', function() {
  setTimeout(function() {
    document.querySelectorAll('.ndq-counter').forEach(function(el) {
      var fin = parseFloat(el.getAttribute('data-target'));
      var suf = el.getAttribute('data-sufijo') || '';
      var dec = parseInt(el.getAttribute('data-dec')) || 0;
      animarContador(el, fin, suf, dec, 950);
    });
  }, 100);
});
"

js_acordeon <- "
$(document).on('click', '.var-acc-header', function() {
  var body = $(this).next('.var-acc-body');
  var icon = $(this).find('.acc-icon');
  var open = body.is(':visible');
  $('.var-acc-body').slideUp(200);
  $('.acc-icon').text('+');
  if (!open) { body.slideDown(220); icon.text('x'); }
});
"

js_interp <- "
function toggleInterp(id) {
  var body = document.getElementById('itbody_' + id);
  var arr  = document.getElementById('itarr_'  + id);
  var btn  = document.getElementById('itbtn_'  + id);
  if (body.style.display === 'block') {
    body.style.display = 'none';
    arr.style.transform = 'rotate(0deg)';
    btn.classList.remove('active');
  } else {
    body.style.display = 'block';
    arr.style.transform = 'rotate(180deg)';
    btn.classList.add('active');
  }
}
"

js_resumen_def <- "
var resumen_defs = {
  'N': {
    nombre: 'N \u2014 Tama\u00f1o de la muestra',
    texto: 'Es el n\u00famero total de observaciones (registros) incluidas en el conjunto de datos analizado. Cada observaci\u00f3n corresponde a un mes dentro del periodo seleccionado.',
    formula: 'N = cantidad de registros mensuales en el rango de fechas'
  },
  'Media': {
    nombre: 'Media \u2014 Promedio aritm\u00e9tico',
    texto: 'Es la suma de todos los valores dividida entre el n\u00famero de observaciones. Representa el valor central t\u00edpico de la distribuci\u00f3n y es sensible a valores extremos (outliers).',
    formula: 'x\u0304 = (\u03a3x\u1d62) / N'
  },
  'DS': {
    nombre: 'DS \u2014 Desviaci\u00f3n est\u00e1ndar',
    texto: 'Mide la dispersi\u00f3n o variabilidad de los datos respecto a la media. Un valor alto indica mayor variabilidad; uno bajo indica que los datos est\u00e1n concentrados cerca de la media.',
    formula: 's = \u221a[ \u03a3(x\u1d62 \u2212 x\u0304)\u00b2 / (N\u22121) ]'
  },
  'Mediana': {
    nombre: 'Mediana \u2014 Valor central',
    texto: 'Es el valor que divide la distribuci\u00f3n en dos mitades iguales cuando los datos est\u00e1n ordenados. A diferencia de la media, no se ve afectada por valores extremos, lo que la hace m\u00e1s robusta.',
    formula: 'Posici\u00f3n central de los datos ordenados (P\u2085\u2080)'
  },
  'Minimo': {
    nombre: 'M\u00ednimo \u2014 Valor m\u00e1s bajo',
    texto: 'Es el valor m\u00e1s peque\u00f1o registrado en el conjunto de datos para el periodo seleccionado. Marca el l\u00edmite inferior de la distribuci\u00f3n.',
    formula: 'min(x\u2081, x\u2082, ..., x\u2099)'
  },
  'Maximo': {
    nombre: 'M\u00e1ximo \u2014 Valor m\u00e1s alto',
    texto: 'Es el valor m\u00e1s grande registrado en el conjunto de datos para el periodo seleccionado. Marca el l\u00edmite superior de la distribuci\u00f3n.',
    formula: 'max(x\u2081, x\u2082, ..., x\u2099)'
  },
  'Q1': {
    nombre: 'Q1 \u2014 Primer cuartil (percentil 25)',
    texto: 'Es el valor por debajo del cual se encuentra el 25% de las observaciones. Junto con Q3 delimita la caja del diagrama de caja y bigotes (boxplot).',
    formula: 'P\u2082\u2085: el 25% de los datos cae por debajo de este valor'
  },
  'Q3': {
    nombre: 'Q3 \u2014 Tercer cuartil (percentil 75)',
    texto: 'Es el valor por debajo del cual se encuentra el 75% de las observaciones. Indica el l\u00edmite superior del rango intercuart\u00edlico.',
    formula: 'P\u2087\u2085: el 75% de los datos cae por debajo de este valor'
  },
  'IQR': {
    nombre: 'IQR \u2014 Rango intercuart\u00edlico',
    texto: 'Es la diferencia entre el tercer y el primer cuartil (Q3 \u2212 Q1). Mide la dispersi\u00f3n del 50% central de los datos y se utiliza para detectar valores at\u00edpicos (outliers).',
    formula: 'IQR = Q3 \u2212 Q1'
  }
};

function mostrarDefResumen(key, el) {
  var panel = document.getElementById('resumen-def-panel');
  var def   = resumen_defs[key];
  if (!def || !panel) return;
  document.querySelectorAll('.resumen-kpi-cell').forEach(function(c) {
    c.classList.remove('active');
  });
  var yaActivo = panel.style.display === 'block' && panel.getAttribute('data-key') === key;
  if (yaActivo) {
    panel.style.display = 'none';
    panel.removeAttribute('data-key');
    return;
  }
  el.classList.add('active');
  document.getElementById('resumen-def-nombre').textContent  = def.nombre;
  document.getElementById('resumen-def-texto').textContent   = def.texto;
  document.getElementById('resumen-def-formula').textContent = def.formula;
  panel.style.display = 'block';
  panel.setAttribute('data-key', key);
}
"

css_main <- "
  body,.content-wrapper,.right-side {
    background-color:#f5f6f8!important;
    font-family:'Inter','Segoe UI',Arial,sans-serif!important;
    color:#1a1a2e!important;
  }
  .skin-blue .main-header .navbar,.skin-blue .main-header .logo {
    background-color:#0a0e1a!important; border-bottom:3px solid #0066cc!important;
  }
  .skin-blue .main-header .logo { color:#fff!important; font-weight:700; font-size:15px; letter-spacing:.5px; }
  .skin-blue .main-header .navbar .nav>li>a { color:#aab4c8!important; }
  .main-sidebar,.left-side { background-color:#0a0e1a!important; box-shadow:2px 0 8px rgba(0,0,0,.15); }
  .skin-blue .sidebar-menu>li>a {
    color:#8899aa!important; font-size:13px; font-weight:500;
    border-left:3px solid transparent; padding:12px 15px; transition:all .2s;
  }
  .skin-blue .sidebar-menu>li.active>a,
  .skin-blue .sidebar-menu>li>a:hover {
    color:#fff!important; border-left:3px solid #0066cc!important; background-color:#141c2e!important;
  }
  .nav-tabs { border-bottom:2px solid #e0e4ea!important; background:transparent!important; }
  .nav-tabs>li>a {
    color:#4a5568!important; background:transparent!important; border:none!important;
    border-bottom:3px solid transparent!important; font-size:13px; font-weight:600;
    padding:10px 18px; text-transform:uppercase; letter-spacing:.5px; transition:all .2s; margin-bottom:-2px;
  }
  .nav-tabs>li.active>a,.nav-tabs>li>a:hover {
    color:#0066cc!important; background:transparent!important; border-bottom:3px solid #0066cc!important;
  }
  .tab-content {
    background:#fff!important; border:1px solid #e0e4ea!important;
    border-top:none!important; padding:24px!important; border-radius:0 0 8px 8px!important;
  }
  .box {
    background:#fff!important; border:1px solid #e0e4ea!important; border-top:none!important;
    border-radius:8px!important; box-shadow:0 2px 8px rgba(0,0,0,.06)!important; margin-bottom:20px;
  }
  .box-header { background:#fff!important; border-bottom:1px solid #e0e4ea!important; padding:14px 20px!important; }
  .box-title  { color:#1a1a2e!important; font-size:14px!important; font-weight:700!important;
                text-transform:uppercase; letter-spacing:.5px; }
  .box-body { padding:20px!important; }
  .kpi-card {
    background:#fff; border:1px solid #e0e4ea; border-radius:12px; padding:20px 22px;
    margin-bottom:16px; box-shadow:0 2px 8px rgba(0,0,0,.05);
    transition:box-shadow .3s,transform .3s; border-left:4px solid #0066cc;
    animation:kpiEntrada .65s cubic-bezier(.22,1,.36,1) both;
  }
  @keyframes kpiEntrada {
    from { opacity:0; transform:translateY(24px) scale(.97); }
    to   { opacity:1; transform:translateY(0) scale(1); }
  }
  .kpi-card:hover { box-shadow:0 8px 24px rgba(0,102,204,.15); transform:translateY(-3px); }
  .kpi-card.green  { border-left-color:#00a854; }
  .kpi-card.red    { border-left-color:#e03131; }
  .kpi-card.orange { border-left-color:#f08c00; }
  .kpi-label { font-size:11px; font-weight:700; color:#6b7280; text-transform:uppercase;
               letter-spacing:1px; display:block; margin-bottom:6px; }
  .kpi-valor { font-size:2.1em; font-weight:800; color:#1a1a2e; display:block; line-height:1.1; }
  .kpi-valor.blue   { color:#0066cc; }
  .kpi-valor.green  { color:#00a854; }
  .kpi-valor.red    { color:#e03131; }
  .kpi-valor.orange { color:#f08c00; }
  .kpi-sub { font-size:11px; color:#9ca3af; margin-top:4px; display:block; }
  .alerta-box {
    border-radius:10px; padding:16px 20px; margin-bottom:18px;
    display:flex; align-items:center; gap:14px; animation:kpiEntrada .5s ease both;
  }
  .alerta-box.danger  { background:linear-gradient(90deg,#fff1f1,#fff5f5); border:1.5px solid #e03131; border-left:5px solid #e03131; }
  .alerta-box.warning { background:linear-gradient(90deg,#fffbeb,#fefce8); border:1.5px solid #f08c00; border-left:5px solid #f08c00; }
  .alerta-box.ok      { background:linear-gradient(90deg,#f0fdf4,#ecfdf5); border:1.5px solid #00a854; border-left:5px solid #00a854; }
  .alerta-icon   { font-size:26px; }
  .alerta-titulo { font-size:13px; font-weight:800; text-transform:uppercase; letter-spacing:.5px; }
  .alerta-texto  { font-size:13px; color:#374151!important; margin:2px 0 0!important; line-height:1.6; }
  .hallazgo-card {
    background:#fff; border:1px solid #e0e4ea; border-radius:12px; padding:18px 20px;
    margin-bottom:12px; box-shadow:0 2px 8px rgba(0,0,0,.04);
    display:flex; gap:16px; align-items:flex-start;
    transition:all .25s; animation:kpiEntrada .5s ease both;
  }
  .hallazgo-card:hover { box-shadow:0 6px 20px rgba(0,0,0,.10); transform:translateX(5px); }
  .hallazgo-icon {
    font-size:18px; min-width:46px; height:46px; border-radius:10px;
    display:flex; align-items:center; justify-content:center; flex-shrink:0; color:#0066cc;
  }
  .hallazgo-titulo { font-size:12px; font-weight:800; color:#1a1a2e; margin-bottom:4px; text-transform:uppercase; letter-spacing:.4px; }
  .hallazgo-texto  { font-size:13px; color:#374151!important; margin:0!important; line-height:1.7; }
  .filtro-global-box {
    background:linear-gradient(90deg,#0a0e1a,#141c2e); border-radius:10px;
    padding:14px 20px; margin-bottom:20px; display:flex; align-items:center; gap:20px; flex-wrap:wrap;
  }
  .filtro-global-box label { color:#aab4c8!important; font-size:11px; font-weight:700;
    text-transform:uppercase; letter-spacing:1px; }
  .filtro-global-box .form-control {
    background:#1e2a3a!important; color:#fff!important;
    border:1px solid #2a3a50!important; border-radius:6px!important; font-size:13px!important;
  }
  .filtro-titulo { color:#fff; font-size:13px; font-weight:700; text-transform:uppercase;
    letter-spacing:1px; white-space:nowrap; }
  h3 { color:#0a0e1a!important; font-size:20px!important; font-weight:700!important; margin-bottom:4px!important; }
  h4 { color:#1a1a2e!important; font-size:14px!important; font-weight:700!important;
       text-transform:uppercase; letter-spacing:.5px; margin-top:24px!important; margin-bottom:10px!important; }
  p  { color:#374151!important; line-height:1.8; font-size:14px; }
  li { color:#374151!important; line-height:2; font-size:14px; }
  .ndq-divider { border:none; border-top:1px solid #e0e4ea; margin:20px 0; }
  .highlight-box { background:#f0f7ff; border-left:4px solid #0066cc; border-radius:0 6px 6px 0; padding:14px 20px; margin:16px 0; }
  .highlight-box p { color:#1a3a5c!important; font-style:italic; margin:0!important; }
  .fase-card { background:#f8fafc; border:1px solid #e0e4ea; border-radius:8px; padding:18px; text-align:center; height:100%; }
  .fase-num    { font-size:2em; font-weight:900; color:#0066cc; display:block; }
  .fase-titulo { font-size:13px; font-weight:700; color:#1a1a2e; text-transform:uppercase; letter-spacing:.5px; display:block; margin:6px 0; }
  .fase-desc   { font-size:12px; color:#6b7280; line-height:1.5; }
  .sidebar-info { padding:10px 15px; font-size:11px; color:#4a5568; line-height:1.9; border-top:1px solid #1e2a3a; margin-top:20px; }
  .ndq-badge { display:inline-block; background:#0066cc; color:#fff; font-size:10px; font-weight:700;
               padding:2px 8px; border-radius:3px; letter-spacing:.5px; vertical-align:middle; margin-left:8px; }
  table.dataTable thead th { background:#f8fafc!important; color:#1a1a2e!important; font-size:12px!important;
    font-weight:700!important; text-transform:uppercase; letter-spacing:.5px; border-bottom:2px solid #0066cc!important; }
  table.dataTable tbody td { font-size:13px; color:#374151!important; border-bottom:1px solid #f0f0f0!important; }
  table.dataTable tbody tr:hover td { background:#f0f7ff!important; }
  .dataTables_filter input,.dataTables_length select {
    border:1px solid #e0e4ea!important; border-radius:4px!important; padding:4px 8px!important; font-size:13px!important;
  }
  pre { background:#f8fafc!important; color:#1a1a2e!important; border:1px solid #e0e4ea!important; border-radius:6px; font-size:12px; }
  ::-webkit-scrollbar { width:5px; height:5px; }
  ::-webkit-scrollbar-track { background:#f5f6f8; }
  ::-webkit-scrollbar-thumb { background:#0066cc; border-radius:3px; }
  .var-accordion { display:flex; flex-direction:column; gap:8px; margin-bottom:20px; }
  .var-acc-item  { border-radius:8px; overflow:hidden; border:1px solid #e0e4ea; transition:box-shadow .2s; }
  .var-acc-item:hover { box-shadow:0 4px 16px rgba(0,0,0,.10); }
  .var-acc-header {
    display:flex; align-items:center; justify-content:space-between;
    padding:14px 18px; cursor:pointer; font-weight:700; font-size:13px; letter-spacing:.3px; user-select:none;
  }
  .var-acc-header .acc-icon { font-size:20px; font-weight:300; opacity:.7; min-width:20px; text-align:center; }
  .var-acc-body { display:none; padding:16px 20px; background:#fff; border-top:1px solid rgba(0,0,0,.06); }
  .var-acc-body ul { margin:0; padding-left:18px; }
  .var-acc-body li { font-size:13px; line-height:2; color:#374151!important; }
  .var-acc-body b  { color:#1a1a2e!important; }
  .acc-tgp-area { background:linear-gradient(90deg,#e8f0fe,#f0f4ff); color:#1a56cc; border-left:4px solid #4285f4; }
  .acc-tgp-nal  { background:linear-gradient(90deg,#dbeafe,#eff6ff); color:#1d4ed8; border-left:4px solid #2563eb; }
  .acc-des-area { background:linear-gradient(90deg,#fee2e2,#fff5f5); color:#b91c1c; border-left:4px solid #ef4444; }
  .acc-des-nal  { background:linear-gradient(90deg,#fecaca,#fff1f1); color:#991b1b; border-left:4px solid #dc2626; }
  .acc-ocu-area { background:linear-gradient(90deg,#d1fae5,#f0fdf4); color:#065f46; border-left:4px solid #10b981; }
  .acc-ocu-nal  { background:linear-gradient(90deg,#a7f3d0,#ecfdf5); color:#064e3b; border-left:4px solid #059669; }
  .var-badge { display:inline-block; font-size:10px; font-weight:700; padding:2px 8px; border-radius:20px;
               margin-left:10px; vertical-align:middle; letter-spacing:.5px; opacity:.9; }
  .badge-azul  { background:#dbeafe; color:#1d4ed8; }
  .badge-rojo  { background:#fee2e2; color:#b91c1c; }
  .badge-verde { background:#d1fae5; color:#065f46; }
  .var-card { border-radius:10px; padding:18px; cursor:pointer; transition:all .25s; color:white;
              margin-bottom:15px; position:relative; overflow:hidden; }
  .var-card:hover { transform:translateY(-4px) scale(1.02); box-shadow:0 10px 25px rgba(0,0,0,.15); }
  .var-title { font-size:13px; font-weight:700; text-transform:uppercase; opacity:.85; }
  .var-sub   { font-size:16px; font-weight:800; margin-top:6px; }
  .blue1  { background:linear-gradient(135deg,#0066cc,#3399ff); }
  .blue2  { background:linear-gradient(135deg,#003366,#0066cc); }
  .red1   { background:linear-gradient(135deg,#e03131,#ff6b6b); }
  .red2   { background:linear-gradient(135deg,#a4161a,#e03131); }
  .green1 { background:linear-gradient(135deg,#00a854,#38d39f); }
  .green2 { background:linear-gradient(135deg,#006644,#00a854); }
  .info-panel { background:white; border-radius:10px; padding:20px; border:1px solid #e0e4ea; margin-top:15px; }
  .resumen-kpi-grid {
    display:flex; flex-wrap:wrap; gap:10px; padding:4px 0; margin-bottom:16px;
  }
  .resumen-kpi-cell {
    background:#f8f9fb; border:1px solid #e2e5ea; border-radius:8px;
    padding:10px 14px; text-align:center; flex:1; min-width:70px;
    cursor:pointer; transition:all .2s;
  }
  .resumen-kpi-cell:hover {
    border-color:#a3c4f4!important; background:#f0f7ff!important; transform:translateY(-2px);
    box-shadow:0 4px 12px rgba(0,102,204,.12);
  }
  .resumen-kpi-cell.active {
    border-color:#0066cc!important; background:#e8f2ff!important;
    box-shadow:0 0 0 2px #a3c4f4;
  }
  .resumen-kpi-label {
    font-size:10px; color:#6b7280; text-transform:uppercase;
    letter-spacing:0.05em; margin-bottom:4px; display:block;
  }
  .resumen-kpi-value {
    font-size:17px; font-weight:600; font-variant-numeric:tabular-nums;
  }
  .resumen-def-panel {
    display:none; background:#f0f7ff; border-left:4px solid #0066cc;
    border-radius:0 8px 8px 0; padding:14px 18px; margin-bottom:16px;
    animation:defEntrada .25s ease both;
  }
  @keyframes defEntrada {
    from { opacity:0; transform:translateY(-6px); }
    to   { opacity:1; transform:translateY(0); }
  }
  .resumen-def-nombre {
    font-size:11px; font-weight:800; color:#0066cc; text-transform:uppercase;
    letter-spacing:1px; margin-bottom:4px;
  }
  .resumen-def-texto {
    font-size:13px; color:#1a3a5c!important; margin:0!important; line-height:1.7;
  }
  .resumen-def-formula {
    font-size:12px; color:#6b7280!important; margin:6px 0 0!important;
    font-style:italic;
  }
  .interp-toggle-wrap { margin-top:14px; margin-bottom:8px; }
  .interp-toggle-btn {
    display:inline-flex; align-items:center; gap:8px;
    background:#f0f7ff; border:1px solid #c8dff7; border-radius:8px;
    padding:9px 16px; cursor:pointer; font-size:13px; font-weight:600;
    color:#0066cc; transition:all .2s; user-select:none;
  }
  .interp-toggle-btn:hover { background:#dbeafe; border-color:#a3c4f4; }
  .interp-toggle-btn.active { background:#dbeafe; border-color:#0066cc; }
  .interp-arrow { font-size:11px; transition:transform .25s; display:inline-block; }
  .interp-toggle-body {
    display:none; margin-top:10px;
    background:#f8fafc; border-left:3px solid #a3c4f4;
    border-radius:0 6px 6px 0; padding:14px 18px;
  }
  .interp-toggle-body p { color:#374151!important; font-size:13px!important; margin:0!important; line-height:1.8; }
"